#!/usr/bin/python

print ( 'Hello Python - Function' )
print "Hello Python - Statement"
